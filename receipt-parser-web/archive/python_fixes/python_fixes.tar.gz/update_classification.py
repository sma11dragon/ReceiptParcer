import json
import re

def levenshtein_distance(s1, s2):
    """Simple Levenshtein distance for short strings"""
    if len(s1) < len(s2):
        return levenshtein_distance(s2, s1)
    if len(s2) == 0:
        return len(s1)
    previous_row = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row
    return previous_row[-1]

def fuzzy_match(word, candidates, max_distance=2):
    """Return the candidate with smallest distance within max_distance, else None"""
    word = word.lower()
    best_candidate = None
    best_distance = float('inf')
    for cand in candidates:
        dist = levenshtein_distance(word, cand.lower())
        if dist < best_distance:
            best_distance = dist
            best_candidate = cand
    if best_distance <= max_distance:
        return best_candidate
    return None

def improve_classification_code(js_code):
    # 1. Expand location list
    # Replace the locationPatterns array with expanded list
    # We need to find the locationPatterns section and replace it.
    # The current locationPatterns:
    #     const locationPatterns = [
    #         /\\b(?:in|at|from)\\s+(singapore|malaysia|thailand|cambodia|indonesia|vietnam|philippines|japan|korea|china|taiwan|hong kong|india)/i,
    #         /\\b(?:in|at|from)\\s+(kuala lumpur|petaling jaya|puchong|johor|penang|singapore|bangkok|phnom penh|jakarta|manila|tokyo|seoul)/i
    #     ];
    # We'll replace with a more comprehensive list and add fuzzy matching logic.
    # Instead of modifying regex, we'll add a new fuzzy matching step after location extraction.
    # We'll keep the regex patterns but also add a fallback fuzzy match for any word after "in|at|from".
    
    # First, we need to insert a new function before the location extraction.
    # Let's find the line "// 8. LOCATION FILTER EXTRACTION (NEW in v7.0)"
    # We'll replace the whole block from that line to the end of locationPatterns loop.
    
    # For simplicity, we'll rewrite the entire js_code with modifications.
    # But that's risky. Instead, we'll do targeted replacements.
    
    # Let's split by lines.
    lines = js_code.split('\n')
    new_lines = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.strip() == '// 8. LOCATION FILTER EXTRACTION (NEW in v7.0)':
            # Keep this line
            new_lines.append(line)
            i += 1
            # Skip the existing locationPatterns lines and replace with new implementation
            # We'll insert our new code until we see the next comment '// 9. PAYMENT METHOD...'
            while i < len(lines) and not lines[i].strip().startswith('// 9.'):
                i += 1
            # Now insert new location extraction logic
            new_lines.append('    // Expanded location list with fuzzy matching')
            new_lines.append('    const knownLocations = [')
            new_lines.append('        "singapore", "malaysia", "thailand", "cambodia", "indonesia", "vietnam", "philippines",')
            new_lines.append('        "japan", "korea", "china", "taiwan", "hong kong", "india", "australia", "usa", "united states",')
            new_lines.append('        "united kingdom", "uk", "germany", "france", "italy", "spain", "netherlands", "switzerland",')
            new_lines.append('        "kuala lumpur", "petaling jaya", "puchong", "johor", "penang", "bangkok", "phnom penh",')
            new_lines.append('        "jakarta", "manila", "tokyo", "seoul", "shanghai", "beijing", "hanoi", "ho chi minh",')
            new_lines.append('        "sydney", "melbourne", "london", "new york", "los angeles", "san francisco"')
            new_lines.append('    ];')
            new_lines.append('    // First try exact match with patterns')
            new_lines.append('    const locationPatterns = [')
            new_lines.append('        /\\b(?:in|at|from)\\s+(singapore|malaysia|thailand|cambodia|indonesia|vietnam|philippines|japan|korea|china|taiwan|hong kong|india)/i,')
            new_lines.append('        /\\b(?:in|at|from)\\s+(kuala lumpur|petaling jaya|puchong|johor|penang|singapore|bangkok|phnom penh|jakarta|manila|tokyo|seoul)/i')
            new_lines.append('    ];')
            new_lines.append('    let locationFound = false;')
            new_lines.append('    for (const pattern of locationPatterns) {')
            new_lines.append('        const match = messageText.match(pattern);')
            new_lines.append('        if (match && match[1]) {')
            new_lines.append('            classification.filters.location = match[1].trim();')
            new_lines.append('            locationFound = true;')
            new_lines.append('            break;')
            new_lines.append('        }')
            new_lines.append('    }')
            new_lines.append('    // If not found, try fuzzy matching for any word after "in|at|from"')
            new_lines.append('    if (!locationFound) {')
            new_lines.append('        const locationWordMatch = messageText.match(/\\b(?:in|at|from)\\s+([a-z]+)/i);')
            new_lines.append('        if (locationWordMatch) {')
            new_lines.append('            const possibleLocation = locationWordMatch[1].toLowerCase();')
            new_lines.append('            // Check if it\'s a skip word')
            new_lines.append('            if (!skipWords.includes(possibleLocation)) {')
            new_lines.append('                // Fuzzy match with known locations')
            new_lines.append('                for (const knownLoc of knownLocations) {')
            new_lines.append('                    if (levenshteinDistance(possibleLocation, knownLoc) <= 2) {')
            new_lines.append('                        classification.filters.location = knownLoc;')
            new_lines.append('                        locationFound = true;')
            new_lines.append('                        break;')
            new_lines.append('                    }')
            new_lines.append('                }')
            new_lines.append('            }')
            new_lines.append('        }')
            new_lines.append('    }')
            new_lines.append('    // If location found, ensure vendor is not set to same value')
            new_lines.append('    if (locationFound && classification.filters.vendor === classification.filters.location) {')
            new_lines.append('        classification.filters.vendor = null;')
            new_lines.append('    }')
            # Now continue to next section
            # We need to skip the old location extraction lines we already omitted.
            # The loop already advanced i past the old location block, so we just continue.
        else:
            new_lines.append(line)
            i += 1
    
    new_js = '\n'.join(new_lines)
    
    # Now we need to add the levenshteinDistance function at the top of the code.
    # Find the line after the opening brace of the for loop? Actually we can add a helper function before the for loop.
    # Let's insert after the variable definitions.
    # We'll do a second pass: find the line "const items = $input.all();" and insert after the helper functions.
    lines = new_js.split('\n')
    new_lines = []
    i = 0
    while i < len(lines):
        line = lines[i]
        new_lines.append(line)
        if line.strip() == 'const items = $input.all();':
            # Insert helper functions after this line
            new_lines.append('    // Helper: Levenshtein distance for fuzzy matching')
            new_lines.append('    function levenshteinDistance(s1, s2) {')
            new_lines.append('        if (s1.length < s2.length) return levenshteinDistance(s2, s1);')
            new_lines.append('        if (s2.length === 0) return s1.length;')
            new_lines.append('        let previousRow = Array.from({length: s2.length + 1}, (_, i) => i);')
            new_lines.append('        for (let i = 0; i < s1.length; i++) {')
            new_lines.append('            let currentRow = [i + 1];')
            new_lines.append('            for (let j = 0; j < s2.length; j++) {')
            new_lines.append('                let insertions = previousRow[j + 1] + 1;')
            new_lines.append('                let deletions = currentRow[j] + 1;')
            new_lines.append('                let substitutions = previousRow[j] + (s1[i] !== s2[j]);')
            new_lines.append('                currentRow.push(Math.min(insertions, deletions, substitutions));')
            new_lines.append('            }')
            new_lines.append('            previousRow = currentRow;')
            new_lines.append('        }')
            new_lines.append('        return previousRow[previousRow.length - 1];')
            new_lines.append('    }')
        i += 1
    
    new_js = '\n'.join(new_lines)
    
    # Also need to ensure vendor extraction does not capture location words.
    # We'll add a check after vendor extraction: if extracted vendor matches a known location (fuzzy), treat as location.
    # We'll do another replacement: find the vendor extraction block and add logic.
    # For now, we'll rely on the earlier rule that clears vendor if same as location.
    # Also we can add a check: if vendor is a known location, move to location.
    # Let's find the line "classification.filters.vendor = potentialVendor;"
    # We'll add before that.
    lines = new_js.split('\n')
    new_lines = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.strip().startswith('classification.filters.vendor = potentialVendor;'):
            # Insert check before this line
            new_lines.append('                // Check if vendor is actually a location')
            new_lines.append('                let isLocation = false;')
            new_lines.append('                for (const knownLoc of knownLocations) {')
            new_lines.append('                    if (levenshteinDistance(potentialVendor.toLowerCase(), knownLoc) <= 2) {')
            new_lines.append('                        classification.filters.location = knownLoc;')
            new_lines.append('                        isLocation = true;')
            new_lines.append('                        break;')
            new_lines.append('                    }')
            new_lines.append('                }')
            new_lines.append('                if (!isLocation) {')
            new_lines.append('                    ' + line)
            new_lines.append('                }')
            i += 1
        else:
            new_lines.append(line)
            i += 1
    
    new_js = '\n'.join(new_lines)
    
    return new_js

def main():
    with open('n8n/v18 Dashboard - Telegram Chat ID Fix.json', 'r') as f:
        data = json.load(f)
    
    for node in data['nodes']:
        if node.get('name') == 'Classify Query Intent':
            old_code = node['parameters']['jsCode']
            print('Old code length:', len(old_code))
            new_code = improve_classification_code(old_code)
            print('New code length:', len(new_code))
            node['parameters']['jsCode'] = new_code
            break
    
    with open('n8n/v18 Dashboard - Telegram Chat ID Fix.json', 'w') as f:
        json.dump(data, f, indent=2)
    
    print('Updated classification node.')

if __name__ == '__main__':
    main()