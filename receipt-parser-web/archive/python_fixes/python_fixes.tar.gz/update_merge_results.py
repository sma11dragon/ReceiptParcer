import json

def main():
    with open('n8n/v18 Dashboard - Telegram Chat ID Fix.json', 'r') as f:
        data = json.load(f)
    
    target_id = '66201913-81df-4ce4-b867-72c0e7bdc13a'
    for node in data['nodes']:
        if node.get('id') == target_id:
            old_code = node['parameters']['jsCode']
            print('Current Merge Results code:', old_code[:200])
            # Modify to handle empty input
            new_code = '''// MERGE SQL RESULTS WITH QUERY CONTEXT - ENHANCED v2.0
// FIXED: Returns classification even when SQL results are empty
const items = $input.all();
const classification = $('Classify Query Intent').first().json;

// If no SQL results, still return classification with empty sql_results
if (!items || items.length === 0) {
    return [{
        json: {
            ...classification,
            sql_results: [],
            result_count: 0,
            empty_results: true
        }
    }];
}

const results = items.map(item => ({
    json: {
        ...classification,
        sql_results: item.json,
        result_count: items.length,
        empty_results: false
    }
}));

return results;'''
            node['parameters']['jsCode'] = new_code
            print('Updated Merge Results with Context node.')
            break
    
    with open('n8n/v18 Dashboard - Telegram Chat ID Fix.json', 'w') as f:
        json.dump(data, f, indent=2)

if __name__ == '__main__':
    main()