import json

with open('n8n/v18 Dashboard - Telegram Chat ID Fix.json', 'r') as f:
    data = json.load(f)

for node in data['nodes']:
    if node.get('name') == 'Classify Query Intent':
        js = node['parameters']['jsCode']
        with open('classification_test.js', 'w') as f:
            f.write(js)
        print('Written classification_test.js')
        break