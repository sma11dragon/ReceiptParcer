import json

def main():
    with open('n8n/v18 Dashboard - Telegram Chat ID Fix.json', 'r') as f:
        data = json.load(f)
    
    target_id = 'a6d1b315-89ae-4b91-8aca-4191542dbbff'
    for node in data['nodes']:
        if node.get('id') == target_id:
            old_code = node['parameters']['jsCode']
            print('Found Simple Formatter node.')
            # We'll replace the empty result handling section with improved version.
            # Let's locate the empty result handling block and modify.
            # For simplicity, we'll replace the whole jsCode with enhanced version.
            # But we need to keep the rest of the code (AI formatting, etc).
            # Let's split by lines and replace the empty result block.
            lines = old_code.split('\n')
            new_lines = []
            i = 0
            while i < len(lines):
                line = lines[i]
                if line.strip().startswith('// Handle empty results with helpful suggestions'):
                    # Keep this line
                    new_lines.append(line)
                    i += 1
                    # Skip until the closing brace of the if block
                    # We'll replace the entire if block with new logic.
                    # We need to know where the block ends.
                    # Let's find the line that starts with 'return [{' after the empty message.
                    # Instead, we'll just replace the whole block with a new one.
                    # Let's capture the current block lines and then replace.
                    # Simpler: we'll just replace from this line to the end of the if block.
                    # We'll write new block manually.
                    # We'll skip lines until we see a line that is not part of the if block.
                    # Look for line that starts with '}' at same indent level.
                    # But we can just assume the block ends after the return statement.
                    # Let's just delete lines until we find a line that starts with '}' and then a line after that maybe '}'.
                    # Too complex.
                    # Instead, we'll replace the entire jsCode with a new one.
                    # Let's do that separately.
                    pass
                new_lines.append(line)
                i += 1
            
            # For now, we'll create new jsCode by string replacement.
            # Let's write new jsCode as a whole.
            # We'll keep the same structure but enhance empty result handling.
            # Let's extract the whole code and replace the empty result block using regex.
            import re
            # Pattern for empty result block
            pattern = r'(\s*// Handle empty results with helpful suggestions.*?\n)(.*?\n)*?\s*return \[\{'
            # Not reliable.
            # Let's just write new jsCode from scratch using the old one as base.
            # We'll output the old code for now.
            new_code = old_code
            # We'll just add a check for empty sql_results array.
            # Find the line "if (!sqlResults || sqlResults.length === 0) {"
            # We'll change condition to also check sql_results empty.
            new_code = new_code.replace(
                'if (!sqlResults || sqlResults.length === 0) {',
                '// Check for empty SQL results\nif (!sqlResults || sqlResults.length === 0 || (sqlResults[0] && sqlResults[0].json && sqlResults[0].json.sql_results && sqlResults[0].json.sql_results.length === 0)) {'
            )
            # Also need to adjust the empty message to include clarification questions.
            # Find the emptyMessage building lines.
            # We'll replace the emptyMessage variable assignment.
            # Let's locate the line "let emptyMessage = '❌ **No expenses found** matching your criteria.\\n\\n';"
            # We'll replace from that line to the end of the block.
            # Let's do a more robust replacement using regex.
            # For simplicity, we'll just append clarification suggestion.
            # We'll add after the existing emptyMessage lines.
            # We'll find the line that ends with "return [{"
            # Let's do with simple string replace.
            new_code = new_code.replace(
                '💡 **Try rephrasing your request:**\\n',
                '💡 **Try rephrasing your request:**\\n• Try different spelling or location name\\n• Use more specific filters (vendor, category, date)\\n• Ask "show all my expenses" to see everything\\n'
            )
            node['parameters']['jsCode'] = new_code
            print('Updated Simple Formatter node.')
            break
    
    with open('n8n/v18 Dashboard - Telegram Chat ID Fix.json', 'w') as f:
        json.dump(data, f, indent=2)

if __name__ == '__main__':
    main()