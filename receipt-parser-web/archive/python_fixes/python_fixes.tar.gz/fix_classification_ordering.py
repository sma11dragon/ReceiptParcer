import json
import re

def fix_ordering(js_code):
    # We need to move knownLocations definition earlier, before vendor extraction.
    # Also levenshteinDistance function must be defined before it's used.
    # Let's split lines and find where knownLocations is defined.
    lines = js_code.split('\n')
    
    # First, find the line where knownLocations is defined (should be in location extraction)
    known_loc_start = -1
    known_loc_end = -1
    for i, line in enumerate(lines):
        if line.strip().startswith('const knownLocations = ['):
            known_loc_start = i
            # Find the closing bracket
            for j in range(i, len(lines)):
                if '];' in lines[j]:
                    known_loc_end = j
                    break
            break
    
    if known_loc_start == -1:
        # Not found, maybe we need to add it.
        print('knownLocations definition not found')
        return js_code
    
    # Extract those lines
    known_loc_lines = lines[known_loc_start:known_loc_end+1]
    
    # Also find levenshteinDistance function definition
    levenshtein_start = -1
    levenshtein_end = -1
    for i, line in enumerate(lines):
        if line.strip().startswith('function levenshteinDistance'):
            levenshtein_start = i
            # Find closing brace
            brace_count = 0
            for j in range(i, len(lines)):
                brace_count += lines[j].count('{')
                brace_count -= lines[j].count('}')
                if brace_count == 0:
                    levenshtein_end = j
                    break
            break
    
    # Move both definitions right after the classification object initialization.
    # Find line after classification object creation.
    # Look for line: "const classification = {"
    class_start = -1
    for i, line in enumerate(lines):
        if 'const classification = {' in line:
            class_start = i
            break
    
    # Find the closing brace of classification object
    if class_start != -1:
        brace_count = 0
        class_end = -1
        for i in range(class_start, len(lines)):
            brace_count += lines[i].count('{')
            brace_count -= lines[i].count('}')
            if brace_count == 0:
                class_end = i
                break
        
        # Insert after class_end
        insertion_point = class_end + 1
        
        # Remove the existing definitions from their current positions
        # We'll create new lines list
        new_lines = []
        i = 0
        while i < len(lines):
            if i == class_end:
                # Add classification closing line
                new_lines.append(lines[i])
                # Insert knownLocations and levenshteinDistance here
                new_lines.append('    // Known locations for fuzzy matching')
                new_lines.extend(known_loc_lines)
                if levenshtein_start != -1:
                    new_lines.append('')
                    new_lines.append('    // Levenshtein distance helper')
                    # Insert the function lines
                    new_lines.extend(lines[levenshtein_start:levenshtein_end+1])
                i += 1
                # Skip the lines we're moving
                if i >= known_loc_start and i <= known_loc_end:
                    i = known_loc_end + 1
                elif i >= levenshtein_start and i <= levenshtein_end:
                    i = levenshtein_end + 1
                else:
                    # continue normally
                    pass
            elif i >= known_loc_start and i <= known_loc_end:
                # Skip these lines, they've been moved
                i += 1
                continue
            elif i >= levenshtein_start and i <= levenshtein_end:
                i += 1
                continue
            else:
                new_lines.append(lines[i])
                i += 1
        
        # Also need to ensure that in vendor extraction we have access to knownLocations.
        # It should now be in scope.
        # However, we also need to ensure that the location extraction block doesn't duplicate knownLocations.
        # The location extraction block currently includes the knownLocations definition; we should remove that.
        # Let's find the location extraction block (starting with "// 8. LOCATION FILTER EXTRACTION")
        # and remove the knownLocations definition lines within it.
        # We'll do a second pass.
        final_lines = []
        i = 0
        while i < len(new_lines):
            line = new_lines[i]
            if line.strip() == '// 8. LOCATION FILTER EXTRACTION (NEW in v7.0)':
                final_lines.append(line)
                i += 1
                # Skip the knownLocations definition if present
                while i < len(new_lines) and new_lines[i].strip().startswith('const knownLocations = ['):
                    i += 1
                    # skip until ];
                    while i < len(new_lines) and '];' not in new_lines[i]:
                        i += 1
                    i += 1
                # Continue adding lines
                while i < len(new_lines) and not new_lines[i].strip().startswith('// 9.'):
                    final_lines.append(new_lines[i])
                    i += 1
                # Continue loop
            else:
                final_lines.append(line)
                i += 1
        
        return '\n'.join(final_lines)
    
    return js_code

def main():
    with open('n8n/v18 Dashboard - Telegram Chat ID Fix.json', 'r') as f:
        data = json.load(f)
    
    for node in data['nodes']:
        if node.get('name') == 'Classify Query Intent':
            old_code = node['parameters']['jsCode']
            print('Fixing ordering...')
            new_code = fix_ordering(old_code)
            node['parameters']['jsCode'] = new_code
            break
    
    with open('n8n/v18 Dashboard - Telegram Chat ID Fix.json', 'w') as f:
        json.dump(data, f, indent=2)
    
    print('Fixed ordering of knownLocations and levenshteinDistance.')

if __name__ == '__main__':
    main()