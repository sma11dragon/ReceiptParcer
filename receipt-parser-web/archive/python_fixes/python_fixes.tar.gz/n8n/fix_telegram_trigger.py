import json
import sys

def fix_workflow(filepath):
    with open(filepath, 'r') as f:
        data = json.load(f)
    
    nodes = data.get('nodes', [])
    updated = False
    
    for node in nodes:
        if node.get('name') == 'Send Registration Prompt':
            params = node.get('parameters', {})
            json_body = params.get('jsonBody', '')
            if '$node["Telegram Trigger"]' in json_body:
                # Replace chat_id reference
                json_body = json_body.replace('$node["Telegram Trigger"].json.message.chat.id', '$json.chat_id')
                params['jsonBody'] = json_body
                node['parameters'] = params
                updated = True
                print('Fixed Send Registration Prompt node')
        
        if node.get('name') == 'Update Verification Token':
            params = node.get('parameters', {})
            query = params.get('query', '')
            if '$node["Telegram Trigger"]' in query:
                # Replace telegram_user_id
                query = query.replace('$node["Telegram Trigger"].json.message.from.id', '$json.telegram_user_id')
                # Replace telegram_username
                query = query.replace("$node[\"Telegram Trigger\"].json.message.from.username", "$json.bot_username || ''")
                # Replace token extraction
                query = query.replace('$node["Telegram Trigger"].json.message.text.split(" ")[1]', '$json.text.split(" ")[1]')
                # Replace chat_id in UPDATE users
                query = query.replace('$node["Telegram Trigger"].json.message.chat.id', '$json.chat_id')
                params['query'] = query
                node['parameters'] = params
                updated = True
                print('Fixed Update Verification Token node')
        
        if node.get('name') == 'Send Welcome Message':
            params = node.get('parameters', {})
            json_body = params.get('jsonBody', '')
            if '$node["Telegram Trigger"]' in json_body:
                json_body = json_body.replace('$node["Telegram Trigger"].json.message.chat.id', '$json.chat_id')
                params['jsonBody'] = json_body
                node['parameters'] = params
                updated = True
                print('Fixed Send Welcome Message node')
        
        if node.get('name') == 'Send Token Error':
            params = node.get('parameters', {})
            json_body = params.get('jsonBody', '')
            if '$node["Telegram Trigger"]' in json_body:
                json_body = json_body.replace('$node["Telegram Trigger"].json.message.chat.id', '$json.chat_id')
                params['jsonBody'] = json_body
                node['parameters'] = params
                updated = True
                print('Fixed Send Token Error node')
    
    if updated:
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
        print('Workflow updated successfully')
    else:
        print('No changes needed')

if __name__ == '__main__':
    fix_workflow('v18 Dashboard - Telegram Chat ID Fix.json')