import re

def fix_workflow(filepath):
    with open(filepath, 'r') as f:
        content = f.read()
    
    original = content
    
    # Pattern 1: $node["Telegram Trigger"].json.message.chat.id
    # Replace with $json.chat_id
    content = re.sub(
        r'\$node\["Telegram Trigger"\]\.json\.message\.chat\.id',
        '$json.chat_id',
        content
    )
    
    # Pattern 2: $node["Telegram Trigger"].json.message.from.id
    # Replace with $json.telegram_user_id
    content = re.sub(
        r'\$node\["Telegram Trigger"\]\.json\.message\.from\.id',
        '$json.telegram_user_id',
        content
    )
    
    # Pattern 3: $node["Telegram Trigger"].json.message.from.username
    # Replace with $json.bot_username (or empty string)
    # This appears inside SQL single quotes: '{{ ... }}'
    # We'll replace the whole '{{ ... }}' with '{{ $json.bot_username || "" }}'
    # But simpler: replace the inner expression
    content = re.sub(
        r'\$node\["Telegram Trigger"\]\.json\.message\.from\.username',
        '$json.bot_username',
        content
    )
    
    # Pattern 4: $node["Telegram Trigger"].json.message.text.split(" ")[1]
    # Replace with $json.text.split(" ")[1]
    content = re.sub(
        r'\$node\["Telegram Trigger"\]\.json\.message\.text',
        '$json.text',
        content
    )
    
    # Pattern 5: $json.message.text (in SQL query)
    content = content.replace('$json.message.text', '$json.text')
    
    if content != original:
        with open(filepath, 'w') as f:
            f.write(content)
        print('Workflow updated successfully')
    else:
        print('No changes needed')

if __name__ == '__main__':
    fix_workflow('v18 Dashboard - Telegram Chat ID Fix.json')