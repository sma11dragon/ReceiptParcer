import re

def fix_workflow(filepath):
    with open(filepath, 'r') as f:
        content = f.read()
    
    original = content
    
    # Match both escaped and non-escaped forms
    patterns = [
        (r'\$node\[\\*"Telegram Trigger\\*"\]\.json\.message\.chat\.id', '$json.chat_id'),
        (r'\$node\[\\*"Telegram Trigger\\*"\]\.json\.message\.from\.id', '$json.telegram_user_id'),
        (r'\$node\[\\*"Telegram Trigger\\*"\]\.json\.message\.from\.username', '$json.bot_username'),
        (r'\$node\[\\*"Telegram Trigger\\*"\]\.json\.message\.text', '$json.text'),
    ]
    
    for pattern, replacement in patterns:
        content = re.sub(pattern, replacement, content)
    
    # Also fix $json.message.text
    content = content.replace('$json.message.text', '$json.text')
    
    if content != original:
        with open(filepath, 'w') as f:
            f.write(content)
        print('Workflow updated successfully')
    else:
        print('No changes needed')

if __name__ == '__main__':
    fix_workflow('v18 Dashboard - Telegram Chat ID Fix.json')