import json
import re
import sys

def fix_workflow(filepath):
    with open(filepath, 'r') as f:
        data = json.load(f)
    
    nodes = data.get('nodes', [])
    updated = False
    
    for node in nodes:
        params = node.get('parameters', {})
        
        # Fix jsonBody in HTTP Request nodes
        if 'jsonBody' in params:
            json_body = params['jsonBody']
            if '$node["Telegram Trigger"]' in json_body:
                # Replace chat_id references
                json_body = re.sub(
                    r'\$node\["Telegram Trigger"\]\.json\.message\.chat\.id',
                    '$json.chat_id',
                    json_body
                )
                # Replace other references if any
                json_body = re.sub(
                    r'\$node\["Telegram Trigger"\]\.json\.message\.from\.id',
                    '$json.telegram_user_id',
                    json_body
                )
                params['jsonBody'] = json_body
                node['parameters'] = params
                updated = True
                print(f'Fixed jsonBody in node: {node.get("name")}')
        
        # Fix SQL queries in PostgreSQL nodes
        if 'query' in params:
            query = params['query']
            if '$node["Telegram Trigger"]' in query:
                # Replace telegram_user_id
                query = re.sub(
                    r'\{\{\s*\$node\["Telegram Trigger"\]\.json\.message\.from\.id\s*\}\}',
                    '{{ $json.telegram_user_id }}',
                    query
                )
                # Replace telegram_username
                query = re.sub(
                    r"'\{\{\s*\$node\["Telegram Trigger"\]\.json\.message\.from\.username\s*\}\}'",
                    "'{{ $json.bot_username || \"\" }}'",
                    query
                )
                # Replace token extraction
                query = re.sub(
                    r"'\{\{\s*\$node\["Telegram Trigger"\]\.json\.message\.text\.split\(" "\)\[1\]\s*\}\}'",
                    "'{{ $json.text.split(\" \")[1] }}'",
                    query
                )
                # Replace chat_id
                query = re.sub(
                    r'\{\{\s*\$node\["Telegram Trigger"\]\.json\.message\.chat\.id\s*\}\}',
                    '{{ $json.chat_id }}',
                    query
                )
                params['query'] = query
                node['parameters'] = params
                updated = True
                print(f'Fixed SQL query in node: {node.get("name")}')
            
            # Fix $json.message.text references (should be $json.text)
            if '$json.message.text' in query:
                query = query.replace('$json.message.text', '$json.text')
                params['query'] = query
                node['parameters'] = params
                updated = True
                print(f'Fixed $json.message.text in node: {node.get("name")}')
        
        # Fix url references (optional)
        if 'url' in params:
            url = params['url']
            if '$node["Telegram Trigger"]' in url:
                url = re.sub(
                    r'\$node\["Telegram Trigger"\]\.json\.message\.chat\.id',
                    '$json.chat_id',
                    url
                )
                params['url'] = url
                node['parameters'] = params
                updated = True
                print(f'Fixed url in node: {node.get("name")}')
    
    if updated:
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
        print('Workflow updated successfully')
    else:
        print('No changes needed')

if __name__ == '__main__':
    fix_workflow('v18 Dashboard - Telegram Chat ID Fix.json')