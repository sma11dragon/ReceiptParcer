import os

with open('README.md', 'r') as f:
    lines = f.readlines()

# Find the line number for "## AI Query Handling Improvements"
start_idx = -1
for i, line in enumerate(lines):
    if line.strip() == '## AI Query Handling Improvements':
        start_idx = i
        break

if start_idx == -1:
    print('Section not found')
    exit(1)

# Find the end of that section (next ## or end of file)
end_idx = start_idx + 1
while end_idx < len(lines) and not lines[end_idx].startswith('## '):
    end_idx += 1

# Now insert new section after end_idx (before next ##)
new_section = '''
## Proposed Feedback Loop Architecture

**Goal**: Create a closed-loop system that learns from user interactions to improve query handling, prevent failures, and enhance user experience.

### Database Schema for Query Logging
```sql
CREATE TABLE query_logs (
    id SERIAL PRIMARY KEY,
    timestamp TIMESTAMP DEFAULT NOW(),
    chat_id BIGINT,
    message_text TEXT,
    classification_json JSONB,
    sql_query TEXT,
    result_count INTEGER,
    outcome_type VARCHAR(20), -- "invalid", "ambiguous", "empty", "success", "error"
    error_message TEXT,
    filters_applied JSONB,
    session_id UUID
);
```

### Strategic Logging Nodes in the Workflow
1. **After Classification**: Log all classification outcomes (`is_valid_expense_query`, `needs_clarification`, extracted filters)
2. **After SQL Execution**: Log SQL queries, result counts, empty results
3. **After Response Formatting**: Log final response type and user-facing message

### Daily Analysis Pipeline
- **Morning Report**: Aggregate yesterday's logs, identify top failure patterns
- **Pattern Recognition**: Common misspellings, ambiguous queries, empty result filters
- **Improvement Suggestions**: New location names, regex adjustments, keyword expansions
- **Email/Slack Report**: Automated daily insights for developers

### Self-Learning Mechanism
- **Pattern Mapping**: Track `failed_query → successful_query` patterns
- **Correction Dictionary**: Automatically add corrections (e.g., "Philppines" → "Philippines")
- **Weekly Updates**: Update `knownLocations`, vendor lists, confidence thresholds
- **Success Rate Monitoring**: Adjust classification based on query success rates

### Privacy Considerations
- Hash `message_text` for analysis while keeping raw for debugging
- Anonymize `chat_id` after 30 days
- Exclude sensitive filters (payment methods) from logging
- GDPR-compliant retention (90 days raw, 1 year aggregated)

### Benefits for Future Interactions
- **Preventive Improvements**: Identify confusion points before they affect many users
- **Predictive Enhancements**: Suggest clarifications before ambiguous queries fail
- **User Experience**: Reduced "no results found" frustration, faster query resolution
- **Engineering Efficiency**: Focus improvements on actual user pain points

### Next Steps for Implementation
1. Add logging nodes to the `ai_query` branch after classification, SQL execution, and formatting
2. Create database table for query logs
3. Implement daily analysis script (Python/Node.js)
4. Build automated improvement suggestion system
5. Integrate with existing classification logic for dynamic updates
'''

# Insert new section
lines = lines[:end_idx] + [new_section] + lines[end_idx:]

with open('README.md', 'w') as f:
    f.writelines(lines)

print('README.md updated with Proposed Feedback Loop Architecture section.')