import json
import re

def remove_debug_from_jscode(code):
    """Remove debug lines from JavaScript code."""
    lines = code.split('\n')
    new_lines = []
    for line in lines:
        # Remove standalone "// Log for debugging" lines
        if line.strip() == '// Log for debugging':
            continue
        # Remove line containing "debug_state: conversationState"
        if 'debug_state:' in line:
            # We need to remove this property from the object
            # The line looks like: '      debug_state: conversationState'
            # We'll skip adding this line entirely
            continue
        new_lines.append(line)
    
    # Join back
    cleaned = '\n'.join(new_lines)
    
    # Also remove any empty lines that might have been created
    # Keep the code structure
    return cleaned

def main():
    with open('n8n/v18 Dashboard - Telegram Chat ID Fix.json', 'r') as f:
        data = json.load(f)
    
    modified = False
    for node in data['nodes']:
        if 'parameters' in node and 'jsCode' in node['parameters']:
            original = node['parameters']['jsCode']
            cleaned = remove_debug_from_jscode(original)
            if cleaned != original:
                node['parameters']['jsCode'] = cleaned
                modified = True
                print(f'Cleaned debug lines from node: {node.get("name", "unnamed")}')
    
    if modified:
        with open('n8n/v18 Dashboard - Telegram Chat ID Fix.json', 'w') as f:
            json.dump(data, f, indent=2)
        print('Debug lines removed and file saved.')
    else:
        print('No debug lines found.')

if __name__ == '__main__':
    main()