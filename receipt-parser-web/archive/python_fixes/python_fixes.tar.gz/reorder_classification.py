import json

def extract_block(lines, start_marker):
    """Extract a block from start_marker to next marker or end of function."""
    start = -1
    for i, line in enumerate(lines):
        if start_marker in line:
            start = i
            break
    if start == -1:
        return None, None, None
    
    # Find end of block: next line that starts with '//' and a number (like '// 8.')
    # or end of function (line that starts with '}' at same indent level)
    # We'll assume block ends before next comment with number.
    end = start + 1
    while end < len(lines):
        line = lines[end]
        if line.strip().startswith('//') and any(str(num) in line for num in range(1, 12)):
            # Next numbered comment
            break
        # Also stop at closing brace of the for loop? Actually the block is inside for loop.
        # We'll just stop at next numbered comment.
        end += 1
    
    block_lines = lines[start:end]
    # Also need to include any lines that are part of the block but before next comment.
    return start, end, block_lines

def main():
    with open('n8n/v18 Dashboard - Telegram Chat ID Fix.json', 'r') as f:
        data = json.load(f)
    
    target_node = None
    for node in data['nodes']:
        if node.get('name') == 'Classify Query Intent':
            target_node = node
            break
    
    if not target_node:
        print('Classify Query Intent node not found')
        return
    
    js_code = target_node['parameters']['jsCode']
    lines = js_code.split('\n')
    
    # Find the three sections
    vendor_marker = '// 7. VENDOR FILTER EXTRACTION (v7.1 - Fixed to exclude common verbs/prepositions)'
    location_marker = '// 8. LOCATION FILTER EXTRACTION (NEW in v7.0)'
    payment_marker = '// 9. PAYMENT METHOD FILTER EXTRACTION (NEW in v7.0)'
    
    vendor_start, vendor_end, vendor_block = extract_block(lines, vendor_marker)
    location_start, location_end, location_block = extract_block(lines, location_marker)
    payment_start, payment_end, payment_block = extract_block(lines, payment_marker)
    
    if not vendor_block or not location_block:
        print('Could not find vendor or location blocks')
        return
    
    # Reorder: location before vendor
    # Build new lines
    new_lines = []
    # Add everything before vendor block
    new_lines.extend(lines[:vendor_start])
    # Add location block
    new_lines.extend(location_block)
    # Add vendor block
    new_lines.extend(vendor_block)
    # Add everything from after location block to before payment block? Actually we need to include lines between vendor_end and location_start?
    # The original order: vendor block, then location block, then payment block.
    # We removed vendor and location blocks, need to add the lines between vendor_end and location_start (should be empty)
    # Then add payment block and the rest.
    # Let's add lines from vendor_end to location_start (should be none)
    if vendor_end < location_start:
        new_lines.extend(lines[vendor_end:location_start])
    # Now add payment block
    new_lines.extend(lines[location_end:payment_start])
    new_lines.extend(payment_block)
    # Add remaining lines after payment block
    new_lines.extend(lines[payment_end:])
    
    # Now we need to improve location extraction logic within location_block.
    # We'll replace the location_block lines with improved version.
    # Let's locate the location_block within new_lines.
    # Find the start index of location_block in new_lines.
    loc_index = -1
    for i, line in enumerate(new_lines):
        if location_marker in line:
            loc_index = i
            break
    
    if loc_index != -1:
        # Replace from loc_index to loc_index + len(location_block) with improved block.
        # We'll write improved location extraction code.
        improved_location = '''    // 8. LOCATION FILTER EXTRACTION (ENHANCED v8.0)
    // Multi-word location support with fuzzy matching
    const locationPatterns = [
        /\\b(?:in|at|from)\\s+(singapore|malaysia|thailand|cambodia|indonesia|vietnam|philippines|japan|korea|china|taiwan|hong kong|india)/i,
        /\\b(?:in|at|from)\\s+(kuala lumpur|petaling jaya|puchong|johor|penang|singapore|bangkok|phnom penh|jakarta|manila|tokyo|seoul)/i
    ];
    let locationFound = false;
    for (const pattern of locationPatterns) {
        const match = messageText.match(pattern);
        if (match && match[1]) {
            classification.filters.location = match[1].trim();
            locationFound = true;
            break;
        }
    }
    // If not found, try fuzzy matching for words after "in|at|from"
    if (!locationFound) {
        const locationPhraseMatch = messageText.match(/\\b(?:in|at|from)\\s+((?:the\\s+)?[a-z\\s]+?)(?=\\s+(?:expenses?|receipts?|transactions?|\\d|$))/i);
        if (locationPhraseMatch) {
            let possibleLocation = locationPhraseMatch[1].trim().toLowerCase();
            // Remove leading "the"
            possibleLocation = possibleLocation.replace(/^the\\s+/i, '');
            // Split into words
            const words = possibleLocation.split(/\\s+/);
            // Check each word and combination against known locations
            for (let i = 0; i < words.length; i++) {
                for (let j = i; j < words.length; j++) {
                    const phrase = words.slice(i, j + 1).join(' ');
                    if (skipWords.includes(phrase)) continue;
                    for (const knownLoc of knownLocations) {
                        if (levenshteinDistance(phrase, knownLoc) <= 2) {
                            classification.filters.location = knownLoc;
                            locationFound = true;
                            break;
                        }
                    }
                    if (locationFound) break;
                }
                if (locationFound) break;
            }
        }
    }
    // If location found, ensure vendor is not set to same value
    if (locationFound && classification.filters.vendor === classification.filters.location) {
        classification.filters.vendor = null;
    }'''
        
        # Remove old location block lines
        del new_lines[loc_index:loc_index + len(location_block)]
        # Insert improved block
        for i, line in enumerate(improved_location.split('\n')):
            new_lines.insert(loc_index + i, line)
    
    # Also need to update vendor extraction to skip location words more effectively.
    # We'll modify the vendor block to check each word against knownLocations.
    # Find vendor block start
    vendor_index = -1
    for i, line in enumerate(new_lines):
        if vendor_marker in line:
            vendor_index = i
            break
    
    if vendor_index != -1:
        # We'll replace the vendor block with improved version.
        # Let's extract the vendor block lines first.
        # We'll just keep the existing vendor block but ensure it doesn't capture locations.
        # The existing vendor block already has location check; we'll keep that.
        # However, we need to ensure that if location extraction already set location, vendor extraction should not overwrite.
        # The vendor block currently runs before location extraction (now after). So vendor extraction may set vendor to location phrase.
        # The location check inside vendor extraction uses knownLocations and levenshteinDistance; that should catch "the Philppines".
        # But it failed because "the Philppines" as whole not close enough.
        # Let's improve that check: split potentialVendor into words and check each word.
        # We'll replace the vendor block with improved version.
        improved_vendor = '''    // 7. VENDOR FILTER EXTRACTION (v7.2 - Enhanced location avoidance)
    // Extract vendor names from queries like "show me Firstcoach receipts"
    // Skip words include common words, verbs, prepositions AND category keywords
    const skipWords = ['my', 'me', 'the', 'all', 'recent', 'latest', 'oldest', 'newest', 'today', 'yesterday', 'this', 'last', 'show', 'list', 'display', 'give', 'get', 'find', 'receipts', 'receipt', 'expenses', 'expense', 'transactions', 'transaction', 'for', 'from', 'at', 'in', 'on', 'about', 'more', 'tell', 'what', 'how', 'many', 'much', 'and', 'or', 'with', 'down', 'up', 'out', 'off', 'over', 'under', 'through', 'into', 'onto', 'upon', 'above', 'below', 'between', 'among', 'around', 'before', 'after', 'during', 'since', 'until', 'to', 'of', 'by', 'as', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'must', 'shall', 'can', 'need', 'dare', 'ought', 'used', 'a', 'an', 'some', 'any', 'no', 'every', 'each', 'either', 'neither', 'both', 'few', 'little', 'less', 'least', 'most', 'other', 'another', 'such', 'that', 'these', 'those', 'which', 'who', 'whom', 'whose', 'where', 'when', 'why', 'breakfast', 'lunch', 'dinner', 'snack', 'coffee', 'transport', 'transportation', 'shopping', 'groceries', 'flight', 'meal', 'meals', 'food', 'drinks', 'drink', 'travel', 'entertainment', 'medical', 'health', 'insurance', 'services', 'singapore', 'malaysia', 'thailand', 'cambodia', 'indonesia', 'vietnam', 'philippines', 'japan', 'korea', 'china', 'taiwan', 'india'];
    const vendorPatterns = [
        /(?:receipts?|expenses?|transactions?)\\s+(?:for|from|at)\\s+([\\w\\s]+?)(?:\\s+(?:in|on|from|to|between|this|last|today|yesterday|\\d)|[?.,!]|$)/i,
        /(?:show|list|find|get|display)\\s+(?:me\\s+)?(?:all\\s+)?([\\w\\s]+?)\\s+(?:receipts?|expenses?|transactions?)/i,
        /(?:how many|count|total)\\s+([\\w\\s]+?)\\s+(?:receipts?|expenses?|transactions?)/i,
        /(?:tell me about|details? (?:for|of|about)|info (?:for|on|about))\\s+([\\w\\s]+?)(?:\\s+(?:receipts?|expenses?|transactions?)|[?.,!]|$)/i
    ];
    for (const pattern of vendorPatterns) {
        const match = originalMessage.match(pattern);
        if (match && match[1]) {
            let potentialVendor = match[1].trim();
            // Remove trailing common words
            potentialVendor = potentialVendor.replace(/\\s+(receipts?|expenses?|transactions?|in|on|from|for)$/i, '').trim();
            // Check if it's a valid vendor (not entirely made up of skip words)
            const words = potentialVendor.toLowerCase().split(/\\s+/);
            const nonSkipWords = words.filter(w => !skipWords.includes(w) && w.length > 1);
            // Only set vendor if there's at least one word that's not a skip word
            if (nonSkipWords.length > 0 && potentialVendor.length > 1) {
                // Check if any word or phrase matches a known location (fuzzy)
                let isLocation = false;
                // Check each word and combinations
                for (let i = 0; i < words.length; i++) {
                    for (let j = i; j < words.length; j++) {
                        const phrase = words.slice(i, j + 1).join(' ');
                        for (const knownLoc of knownLocations) {
                            if (levenshteinDistance(phrase, knownLoc) <= 2) {
                                classification.filters.location = knownLoc;
                                isLocation = true;
                                break;
                            }
                        }
                        if (isLocation) break;
                    }
                    if (isLocation) break;
                }
                if (!isLocation) {
                    classification.filters.vendor = potentialVendor;
                }
                break;
            }
        }
    }'''
        
        # Remove old vendor block lines
        # Find end of vendor block (next numbered comment)
        vendor_end_idx = vendor_index + 1
        while vendor_end_idx < len(new_lines):
            if new_lines[vendor_end_idx].strip().startswith('//') and any(str(num) in new_lines[vendor_end_idx] for num in range(1, 12)):
                break
            vendor_end_idx += 1
        
        del new_lines[vendor_index:vendor_end_idx]
        # Insert improved vendor block
        for i, line in enumerate(improved_vendor.split('\n')):
            new_lines.insert(vendor_index + i, line)
    
    # Update js_code
    target_node['parameters']['jsCode'] = '\n'.join(new_lines)
    
    # Write back
    with open('n8n/v18 Dashboard - Telegram Chat ID Fix.json', 'w') as f:
        json.dump(data, f, indent=2)
    
    print('Reordered classification steps and improved location extraction.')

if __name__ == '__main__':
    main()